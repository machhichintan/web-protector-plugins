=== Dashicons + Custom Post Types ===
Contributors: halgatewood
Donate link: https://halgatewood.com/donate/
Tags: dash icons, icons, wordpress menu, menu, admin menu
Requires at least: 4.1.1
Tested up to: 4.9
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Easily change the admin menu icons for custom post types.

== Description ==

The Dashicons + Custom Post Types plugin allows you to keep the WordPress admin menu as clean as possible. When your building new custom post types for your clients your default icon in the admin menu is the pin. This is no fun. With my plugin you can easily and quickly change all the custom post type icons to match the rest of the icons in the menu.

https://www.youtube.com/watch?v=3M6-mU9Ai0M



== Installation ==

Do whatever it takes to get the plugin on your site. But most likely you’ve already done so.

https://www.youtube.com/watch?v=3M6-mU9Ai0M


== Screenshots ==

1. Settings Menu
2. Interface to select which icon to use for each custom post type
3. Finished outcome in the admin menu

== Changelog ==

= 1.0.2 =
* Updated icon set

= 1.0.1 =
* Allowed you to remove a selection

= 1.0 =
* Initial load of the plugin

