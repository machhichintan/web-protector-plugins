<?php
// Isset start 
    if ( isset( $_POST['protector_check'] ) ) {

        //All Protector start
        if ( isset( $_POST['front_back'] ) ) {
            update_option( 'front_back', 'yes' );
        } else {
            update_option( 'front_back', 'no' );
        }
        //All Protector End
        
        //F12 Protector start
        if ( isset( $_POST['front_f12'] ) ) {
            update_option( 'front_f12', 'yes' );
        } else {
            update_option( 'front_f12', 'no' );
        }
        //F12 Protector End
        
        //Ctrl U Protector start
        if (isset( $_POST['front_ctrl_u'] ) ) {
            update_option( 'front_ctrl_u', 'yes' );
        } else {
            update_option( 'front_ctrl_u', 'no' );
        }
        //Ctrl U Protector End
        
        //Right Click Protector start
        if ( isset( $_POST['right_click'] ) ) {
            update_option( 'right_click', 'yes' );
        } else {
            update_option('right_click', 'no');
        }
        //Right Click Protector End
        
        //Copy text Protector start
        if ( isset( $_POST['text_copy'] ) ) {
            update_option( 'text_copy', 'yes' );
        } else {
            update_option( 'text_copy', 'no' );
        }
        //Copy text Protector End
        
        //Paste text Protector Start
        if (isset( $_POST['text_paste'] ) ) {
            update_option( 'text_paste', 'yes' );
        } else {
            update_option( 'text_paste', 'no' );
        }
        //Copy text Protector End
        
        //Cut text Protector Start
        if ( isset( $_POST['text_cut'] ) ) {
            update_option( 'text_cut', 'yes' );
        } else {
            update_option( 'text_cut', 'no' );
        }
        //Cut text Protector End
    }


    $front_back = get_option( 'front_back' );
    $front_f12 = get_option( 'front_f12' );
    $front_ctrl_u = get_option( 'front_ctrl_u' );
    $right_click = get_option( 'right_click' );
    $text_copy = get_option( 'text_copy' );
    $text_paste = get_option( 'text_paste' );
    $text_cut = get_option( 'text_cut' );
//isset End
?>
<div class="wrap">
    <h2><?php esc_html_e('Website Protector', 'website-protector') ?></h2>
    <div class="tablenav top"></div>
    <form action="" method="post" name="check">
        <div class="active_plugins">
            <div class="active_select_all">
                <p>
                    <label><input type="checkbox" name="front_back" id="check_all" <?php echo ( get_option('front_back') == 'yes' ) ? 'checked' : ''; ?>>
                        <span>Check All</span>
                    </label>
                </p>
                <h2><?php esc_html_e('Website Protector', 'website-protector'); ?></h2>
            </div>
            <div class="web_protector">
                <ul>
                    <li>
                        <p>
                            <label><input type="checkbox" name="front_f12" class="child_box" <?php echo ( get_option('front_f12') == 'yes' ) ? 'checked' : ''; ?>>
                                <span>F12 Key</span>
                            </label>
                        </p>
                        <p>
                            <label><input type="checkbox" name="front_ctrl_u" class="child_box" <?php echo ( get_option('front_ctrl_u') == 'yes' ) ? 'checked' : ''; ?>>
                                <span>Ctrl + U</span>
                            </label>
                        </p>
                    </li>
                    <li>
                        <p>
                            <label><input type="checkbox" name="right_click" class="child_box" <?php echo ( get_option('right_click') == 'yes' ) ? 'checked' : ''; ?>>
                                <span>Rigth Click</span>
                            </label>
                        </p>
                        <p>
                            <label><input type="checkbox" name="text_copy" class="child_box" <?php echo ( get_option('text_copy') == 'yes' ) ? 'checked' : ''; ?>>
                                <span>Copy Text</span>
                            </label>
                        </p>
                    </li>
                    <li>
                        <p>
                            <label><input type="checkbox" name="text_paste" class="child_box" <?php echo ( get_option('text_paste') == 'yes' ) ? 'checked' : ''; ?>>
                                <span>Paste Text</span>
                            </label>
                        </p>
                        <p>
                            <label><input type="checkbox" name="text_cut" class="child_box" <?php echo ( get_option('text_cut') == 'yes' ) ? 'checked' : ''; ?>>
                                <span>Cut Text</span>
                            </label>
                        </p>
                    </li>
                    <p class="submit">
                        <a name="protector_check" id="web_protector" class="waves-effect waves-light btn-large">Submit</a>
                        <!-- <input type="submit" name="protector_check" class="waves-effect waves-light btn-large" /> -->
                    </p>
                </ul>
            </div>
        </div>
    </form>
</div>
<script type="text/javascript">
    jQuery(document).ready(function () {
        //alert();
        jQuery("#check_all").click(function () {
            //alert("Hello");
            jQuery(".child_box").prop("checked", this.checked);
        });

        jQuery(".child_box").click(function () {

            if (jQuery('.child_box:checked').length == jQuery(".child_box").length) {
                jQuery("#check_all").prop("checked", true);
            } else {
                jQuery("#check_all").prop("checked", false);
            }
        });
    });
</script>
