<?php
/*
  Plugin Name: Website Protector
  Plugin URI: https://profiles.wordpress.org/machhichintan
  Description: Website Protector Plugin
  Author: Machhi Chintan
  Author URI: https:facebook.com/chintan207
 */

//is Not admin start


error_reporting(1);
if (!is_admin()) {
    $protector = plugins_url('website-protector');
    ?>

    <script src="<?php echo $protector; ?>/assets/js/jquery-1.9.1.min.js"></script>
    <link rel="stylesheet" type="text/css" href="<?php echo $protector; ?>/style.css"> 

    <div class="hide" style="display:none;">
    <?php require_once 'protector.php'; ?>
    </div><?php
    //All Key enable/ disable start
    if ($front_back == "yes") {
        ?>
        <script src="<?php //echo $protector;  ?>/protector.js"></script>
        <?php
    }
    //All Key enable/ disable end
    //F12 enable/ disable start
    if ($front_f12 == "yes") {
        ?>
        <script>
            jQuery(document).keydown(function (event) {
                if (event.keyCode == 123) {
                    return false;
                } else if (event.ctrlKey && event.shiftKey && event.keyCode == 73) {
                    return false;
                }
            });
        </script> <?php
    }
    //F12 enable/ disable end
    //Ctrl U enable/ disable start
    if ($front_ctrl_u == "yes") {
        ?>
        <script>
            document.onkeydown = function (e) {
                if (e.ctrlKey && (e.keyCode === 67 || e.keyCode === 86 || e.keyCode === 85 || e.keyCode === 117)) {
                    //alert('not allowed');
                    return false;
                } else {
                    return true;
                }
            };
        </script> <?php
    }
    //Ctrl U enable/ disable end
    //Right Click enable/ disable start
    if ($right_click == "yes") {
        ?>
        <script>
            jQuery(document).ready(function () {
                jQuery("body").on("contextmenu", function (e) {
                    return false;
                });
            });
        </script> <?php
    }
    //Right Click enable/ disable end
    //Text Copy enable/ disable start
    if ($text_copy == "yes") {
        ?>
        <script>
            jQuery('body').bind(' copy ', function (e) {
                e.preventDefault();
            });
        </script> <?php
    }
    //Text Copy enable/ disable end
    //Text paste enable/ disable start
    if ($text_paste == "yes") {
        ?>
        <script>
            jQuery('body').bind(' paste ', function (e) {
                e.preventDefault();
            });
        </script> <?php
    }
    //Text paste enable/ disable end
    //Text cut enable/ disable start
    if ($text_cut == "yes") {
        ?>
        <script>
            jQuery('body').bind(' cut ', function (e) {
                e.preventDefault();
            });
        </script> <?php
    }
    //Text cut enable/ disable end
} else {
    if (($_GET['page'] == 'website-protector') || ($_GET['page'] == 'plugins-protector')) {
        add_action('admin_enqueue_scripts', 'websiteprotector_scripts_basic');
    }
}
//is Not admin end
//admin menu Hook start
add_action('admin_menu', 'website_backend_menu');

//admin menu Hook ebd
//Create admin menu start
function website_backend_menu() {

    add_menu_page('Website Protector', 'Website Protector', 'manage_options', 'website-protector', 'website_protector', 'dashicons-lock');
    add_submenu_page('website-protector', 'Plugins Protector', 'Plugins Protector', 'manage_options', 'plugins-protector', 'plugins_protector');
    add_submenu_page('website-protector', 'Themes Protector', 'Themes Protector', 'manage_options', 'themes-protector', 'themes_protector');
}

//Create admin menu	end
//Menu Functionality start
function website_protector() {
    require_once 'protector.php';
}

function plugins_protector() {
    require_once 'template/plugins-protector.php';
}

function themes_protector() {
    require_once 'template/theme-protector.php';
}

//Menu Functionality end
//plugins scripts and style start
function websiteprotector_scripts_basic() {
    $protector = plugins_url('website-protector');
    wp_register_script('custom-script', plugins_url('/materialize/js/materialize.js', __FILE__));
    wp_enqueue_script('custom-script');

    wp_register_style('custom-style', plugins_url('/materialize/css/materialize.css', __FILE__));
    wp_enqueue_style('custom-style');

    wp_register_style('custom-style1', plugins_url('/assets/css/admin-css.css', __FILE__));
    wp_enqueue_style('custom-style1');

    wp_register_style('custom-style2', plugins_url('/assets/css/my.css', __FILE__));
    wp_enqueue_style('custom-style2');
}
