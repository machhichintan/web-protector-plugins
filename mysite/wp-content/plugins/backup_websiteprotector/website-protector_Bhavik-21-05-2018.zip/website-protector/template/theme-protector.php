<?php 
	echo "Hello";
	exit;
?>