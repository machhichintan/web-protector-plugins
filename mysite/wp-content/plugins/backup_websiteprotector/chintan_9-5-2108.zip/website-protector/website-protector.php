<?php
/*
Plugin Name: Website Protector
Plugin URI: https://profiles.wordpress.org/machhichintan
Description: Website Protector Plugin
Author: Machhi Chintan
Author URI: https:facebook.com/chintan207
*/



if(!is_admin()) { ?>
	<div class="hide" style="display:none;">
		<?php require_once 'protector.php'; ?>
	</div>
	<?php
	
	//echo $front_back;
	if($front_back == "yes"){
		$protector = plugins_url('website-protector'); 
		?>
		<script src="<?php echo $protector; ?>/assets/js/jquery-1.9.1.min.js"></script>
		<script src="<?php echo $protector; ?>/protector.js"></script>
		<link rel="stylesheet" type="text/css" href="<?php echo $protector; ?>/style.css"> 
		<?php
	}
}

//admin menu Hook
add_action( 'admin_menu', 'website_backend_menu' );

function website_backend_menu() {
	$protector = plugins_url('website-protector'); ?>

	<link rel="stylesheet" type="text/css" href="<?php echo $protector; ?>/assets/css/admin-css.css"> <?php
	
	add_menu_page( 'Website Protector', 'Website Protector', 'manage_options', 'website-protector', 'website_protector', plugins_url( 'website-protector/assets/images/protector.png' ));
	add_submenu_page( 'website-protector', 'Plugins Protector', 'Plugins Protector', 'manage_options', 'plugins-protector', 'plugins_protector');
		
}
function website_protector() {
	require_once 'protector.php';
	//$front_back = get_option('front_back');
	//echo $front_back;
}
function plugins_protector() {
	require_once 'template/plugins-design.php';
}
function website_call1() { 
	echo "<h2>" . __( 'Test Page', 'website-protector' ) . "</h2>";	
}
function website_call2() { 
	echo "<h2>" . __( 'Test1 Page', 'website-protector' ) . "</h2>";	
}