<?php
// this theme has no sidebar