<?php

if ( ! isset( $content_width ) )
	$content_width = 740;

// replacement for twenty ten setup
function twentyten_setup() {

	add_theme_support( 'post-thumbnails' );

	add_theme_support( 'automatic-feed-links' );

	load_theme_textdomain( 'twentyten', TEMPLATEPATH . '/languages' );

	$locale = get_locale();
	$locale_file = TEMPLATEPATH . "/languages/$locale.php";
	if ( is_readable( $locale_file ) )
		require_once( $locale_file );

	load_theme_textdomain( 'mazeld', STYLESHEETPATH . '/languages' );

	$locale = get_locale();
	$locale_file = STYLESHEETPATH . "/languages/$locale.php";
	if ( is_readable( $locale_file ) )
		require_once( $locale_file );

	register_nav_menus( array(
		'primary' => __( 'Primary Navigation', 'twentyten' ),
	) );
}

function yellow_widgets_init() {
	// this theme has no sidebar, so no widget spaces are needed for it
	unregister_sidebar( 'primary-widget-area' );
	unregister_sidebar( 'secondary-widget-area' );
}
add_action( 'widgets_init', 'yellow_widgets_init' , 20 ); // 20 to ensure we run after twentyten's widgets handler

function yellow_aside_handler($content) {
	if (is_home() && in_category( array( 'asides' ) ) ) {
		$content .= ' <span class="ending"><a href="'.get_permalink().'#comments">(';
		$content .= get_comments_number();
		$content .= ')</a> <a href="'.get_permalink().'">&para;</a></span>';
	}
	return $content;
}
add_filter('the_content','yellow_aside_handler',1);

// add anchors to attachment links to go directly to the images
function yellow_attachment_link($link) {
	return $link.'#posttitle';
}
add_filter('attachment_link','yellow_attachment_link');

// function to get a random photo thumbnail
function yellow_get_random_photo() {
	global $wpdb;
	$gotit = 0;
	$random = '';
	while ( $gotit == 0 && $hilites = $wpdb->get_results( "SELECT ID, post_parent FROM $wpdb->posts WHERE post_type = 'attachment' AND post_date_gmt >= '2008-01-01 00:00:00' ORDER BY RAND() LIMIT 10" ) ) {
		foreach ( $hilites as $hilite ) {
			if ( $gotit == 1 )
				continue;
			if ( $id = $wpdb->get_var( "SELECT ID FROM $wpdb->posts WHERE ID = '$hilite->post_parent' AND post_date_gmt >= '2008-01-01 00:00:00'" ) ) {
				$gotit = 1;
				$random = '<a href="' . get_permalink( $hilite->ID ) . '">' . wp_get_attachment_image( $hilite->ID, 'thumbnail' ) . '</a>';
			}
		}
	}
	return $random;
}

function twentyten_posted_on() {
	$y = get_the_time('Y');
	$m = get_the_time('n');
	$d = get_the_time('j');
	printf( '<li class="when entry-date">%1s<li>',
		sprintf ('<a href="%1s">%2s</a> <a href="%3s">%4s</a>, <a href="%5s">%6s</a> %7s',
			get_month_link($y,$m), get_the_time('F'),
			get_day_link($y,$m,$d), get_the_time('jS'),
			get_year_link($y), $y,
			get_the_time('g:i a')
		)
	);
}

function twentyten_posted_in() {
	$list = join (', ', array( get_the_category_list( ', ' ), get_the_tag_list( '', ', ' ) ) );

	if ( !empty( $list ) ) printf( '<li class="where">' . __('Filed under: %1s','mazeld') . '</li>', $list );
}
