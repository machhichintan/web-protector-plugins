	</div><!-- #main -->

	<div id="footer" role="contentinfo">
		<div id="colophon">

<?php get_sidebar( 'footer' ); ?>

			<div id="site-info">
<p><?php printf( __('This page took %s seconds of computer labor to produce. No computers were harmed in the making of this page.', 'mazeld'), timer_stop(0) ); ?></p>
			</div><!-- #site-info -->

			<div id="site-generator">
				<?php do_action( 'twentyten_credits' ); ?>
				<a href="<?php echo esc_url( __('http://wordpress.org/', 'twentyten') ); ?>"
						title="<?php esc_attr_e('Semantic Personal Publishing Platform', 'twentyten'); ?>" rel="generator">
					<?php printf( __('Proudly powered by %s.', 'twentyten'), 'WordPress' ); ?>
				</a>
			</div><!-- #site-generator -->
			<div id="themelink"><a href="http://ma.tt" title="ma.tt"><?php _e('Mazeld theme by ma.tt','mazeld'); ?></a></div>

		</div><!-- #colophon -->
	</div><!-- #footer -->
</div></div>

<?php wp_footer(); ?>
</body>
</html>
